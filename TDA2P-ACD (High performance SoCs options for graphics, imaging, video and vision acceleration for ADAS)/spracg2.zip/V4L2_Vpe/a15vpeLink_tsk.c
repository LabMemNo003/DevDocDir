/*
 *******************************************************************************
 *
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 * ALL RIGHTS RESERVED
 *
 *******************************************************************************
 */

/**
 *******************************************************************************
 * \file a15vpeLink_tsk.c
 *
 * \brief  This file has the implementation of A15 VPE Link Init and Run API
 *
 *         This file implements the state machine logic for this link.
 *         VpeLink_init() get calls from system_init and the same create
 *         the link task and basic messaging interfaces. Once the link is
 *         initiated it waits for the create cmd. This create cmd creates the
 *         complete link infrastructure.  Then waits for various data and
 *         control cmds.
 *
 *         This file also implements the vpe link tear down functionality
 *
 * \version 0.0 (Sept 2013) : [SS] First version
 *
 *******************************************************************************
*/

/*******************************************************************************
 *  INCLUDE FILES
 *******************************************************************************
 */
#include "a15vpeLink_priv.h"

/**
 *******************************************************************************
 * \brief VPE Link object, stores all link related information
 *******************************************************************************
 */
A15VpeLink_Obj gA15VpeLink_obj[A15_VPE_LINK_OBJ_MAX];

/**
 *******************************************************************************
 *
 * \brief This function implements the A15 VPE link Create, Run/Steady state
 *
 *        In this state link gets commands to
 *         - Create the VPE Driver
 *         - Stop/delete of link
 *         - Data events/cmds
 *         - All dynamic cmds that the link supports
 *         - All stats/status cmds
 *
 * \param  pTsk [IN] Task Handle
 * \param  pMsg [IN] Message Handle
 *
 * \return  void
 *
 *******************************************************************************
 */
Int32 A15VpeLink_tskMain(struct OSA_TskHndl * pTsk, OSA_MsgHndl * pMsg, UInt32 curState)
{
    UInt32 cmd = OSA_msgGetCmd(pMsg);
    Bool ackMsg, done, stopDone;
    Int32 status=SYSTEM_LINK_STATUS_SOK;
    A15VpeLink_ChannelInfo * channelInfo;
    A15VpeLink_Obj *pObj;
    //UInt32 flushCmds[2];

    pObj = (A15VpeLink_Obj *) pTsk->appData;

    memset(pObj->chObj, 0, sizeof(*(pObj->chObj)));
    /*
     * At this stage only create command is the expected command.
     * If other message gets received Ack with error status
     */
    if (cmd != SYSTEM_CMD_CREATE)
    {
        OSA_tskAckOrFreeMsg(pMsg, OSA_EFAIL);
        return SYSTEM_LINK_STATUS_EFAIL;
    }

    /*
     * Create command received, create the driver
     */
    status = A15VpeLink_drvCreate(pObj, OSA_msgGetPrm(pMsg));

    OSA_tskAckOrFreeMsg(pMsg, status);

    if (status != SYSTEM_LINK_STATUS_SOK)
        return status;

    done = FALSE;
    ackMsg = FALSE;
    stopDone = FALSE;

    /*
     * This while loop implements RUN state. All the run time commands for
     * ackMsg Link are received and serviced in this while loop.
     * Control remains in this loop until delete commands arrives.
     */
    while (!done)
    {
        status = OSA_tskWaitMsg(pTsk, &pMsg);
        if (status != SYSTEM_LINK_STATUS_SOK)
            break;

        cmd = OSA_msgGetCmd(pMsg);

        if(stopDone==TRUE && cmd!=SYSTEM_CMD_DELETE)
        {
            /* once stop is done, only DELETE command should be accepted */
            OSA_tskAckOrFreeMsg(pMsg, status);
            continue;
        }

        /*
         * Different commands are serviced via this switch case. For each
         * command, after servicing, ACK or free message is sent before
         * proceeding to next state.
         */
        switch (cmd)
        {
            case SYSTEM_CMD_NEW_DATA:
                OSA_tskAckOrFreeMsg(pMsg, status);

                //flushCmds[0] = SYSTEM_CMD_NEW_DATA;
                OSA_tskFlushMsg(pTsk);

                A15VpeLink_drvProcessData(pObj);
                break;

            case SYSTEM_CMD_PRINT_STATISTICS:
                A15VpeLink_printStatistics(pObj, TRUE);
                OSA_tskAckOrFreeMsg(pMsg, status);
                break;

            case SYSTEM_CMD_PRINT_BUFFER_STATISTICS:
                A15VpeLink_printBufferStatus(pObj);
                OSA_tskAckOrFreeMsg(pMsg, status);
                break;
#if 0
            case VPE_LINK_CMD_GET_OUTPUTRESOLUTION:
                {
                    VpeLink_ChDynamicSetOutRes *params;

                    params = (VpeLink_ChDynamicSetOutRes *) OSA_msgGetPrm(pMsg);
                    A15VpeLink_drvGetChDynamicOutputRes(pObj, params);
                    OSA_tskAckOrFreeMsg(pMsg, status);
                }
                break;

            case VPE_LINK_CMD_SET_OUTPUTRESOLUTION:
                {
                    VpeLink_ChDynamicSetOutRes *params;

                    params = (VpeLink_ChDynamicSetOutRes *) OSA_msgGetPrm(pMsg);
                    A15VpeLink_drvSetChDynamicOutputRes(pObj, params);
                    OSA_tskAckOrFreeMsg(pMsg, status);
                }
                break;
#endif

            case A15_VPE_LINK_CMD_SET_FRAME_RATE:
                {
                    A15VpeLink_ChFpsParams *params;

                    params = (A15VpeLink_ChFpsParams *) OSA_msgGetPrm(pMsg);
                    A15VpeLink_drvSetFrameRate(pObj, params);
                    OSA_tskAckOrFreeMsg(pMsg, status);
                }
                break;

            case A15_VPE_LINK_CMD_ENABLE_CHANNEL:

                channelInfo = (A15VpeLink_ChannelInfo *) OSA_msgGetPrm(pMsg);

                A15VpeLink_drvSetChannelInfo(pObj,channelInfo);

                OSA_tskAckOrFreeMsg(pMsg, status);

                break;
            case SYSTEM_CMD_STOP:
                A15VpeLink_drvStop(pObj);
                OSA_tskAckOrFreeMsg(pMsg, status);
                stopDone = TRUE;
                break;

            case SYSTEM_CMD_DELETE:
                done = TRUE;
                ackMsg = TRUE;
                break;

            default:
                OSA_tskAckOrFreeMsg(pMsg, status);
                break;
        }
    }

    A15VpeLink_drvDelete(pObj);
    if (ackMsg && pMsg != NULL)
        OSA_tskAckOrFreeMsg(pMsg, status);

    return status;
}

/**
 *******************************************************************************
 *
 *   \brief VPE link register and init function
 *
 *          - Creates link task
 *          - Registers as a link with the system API
 *
 *   \return  SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
*/
Int32 A15VpeLink_init()
{
    Int32 status;
    System_LinkObj linkObj;
    A15VpeLink_Obj *pObj;

    UInt32 objId;

    for (objId = 0; objId < A15_VPE_LINK_OBJ_MAX; objId++)
    {
        pObj = &gA15VpeLink_obj[objId];

        memset(pObj, 0, sizeof(*pObj));

        pObj->linkId = SYSTEM_LINK_ID_A15VPE_0 + objId;

        linkObj.pTsk = &pObj->tsk;
        linkObj.linkGetFullBuffers  = A15VpeLink_getFullBuffers;
        linkObj.linkPutEmptyBuffers = A15VpeLink_putEmptyBuffers;
        linkObj.getLinkInfo         = A15VpeLink_getLinkInfo;

        sprintf(pObj->name, "VPE%d    ", (int) objId);

        System_registerLink(pObj->linkId, &linkObj);

        /*
         * Create link task, task remains in IDLE state.
         * VpeLink_tskMain is called when a message command is received.
         */
        status = OSA_tskCreate(&pObj->tsk,
                                 A15VpeLink_tskMain,
                                 A15_VPE_LINK_TSK_PRI,
                                 A15_VPE_LINK_TSK_STACK_SIZE,
                                 0,
                                 pObj);
        OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
    }

    return status;
}

/**
 *******************************************************************************
 *
 *   \brief VPE link de-register and de-init function
 *
 *          - Deletes link task
 *          - De-registers as a link with the system API
 *
 *   \return  SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
*/
Int32 A15VpeLink_deInit()
{
    UInt32 objId;
    A15VpeLink_Obj *pObj;

    for (objId = 0; objId < A15_VPE_LINK_OBJ_MAX; objId++)
    {
        pObj = &gA15VpeLink_obj[objId];

        OSA_tskDelete(&pObj->tsk);
    }

    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief This function return the channel info to the next link
 *
 * \param  pTsk     [IN]  Task Handle
 * \param  pTsk     [OUT] channel info
 *
 * \return  SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_getLinkInfo(Void * pTsk, System_LinkInfo * info)
{
    OSA_TskHndl * pTskHndl = (OSA_TskHndl *)pTsk;
    A15VpeLink_Obj *pObj = (A15VpeLink_Obj *) pTskHndl->appData;

    /* 'info' structure is set with valid values during 'create' phase */
    memcpy(info, &pObj->info, sizeof(*info));
    printf("A15VpeLink_getLinkInfo called queueNum %d Channel Num %d Width %d Height %d\n",info->numQue,info->queInfo[0].numCh,info->queInfo[0].chInfo[0].width,info->queInfo[0].chInfo[0].height);
    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief Callback function implemented by link to give full buffers to next
 *        link.
 *
 * VPE link sends message to next link about availability of buffers.
 * Next link calls this callback function to get full buffers from VPE link
 * output queue.
 *
 * \param  ptr      [IN] Task Handle
 * \param  queId    [IN] queId from which buffers are required.
 * \param  pBufList [IN] Pointer to link information handle
 *
 * \return  SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
*/
Int32 A15VpeLink_getFullBuffers(Void * ptr, UInt16 queId,
                             System_BufferList * pBufList)
{
    Int32 status;
    //UInt64 timestamp=0;
	
    OSA_TskHndl *pTsk = (OSA_TskHndl *) ptr;

    A15VpeLink_Obj *pObj = (A15VpeLink_Obj *) pTsk->appData;

    OSA_assert(queId < A15_VPE_LINK_OUT_QUE_ID_MAX);

    status =  OSA_bufGetFull(&pObj->outObj[queId].bufOutQue, pBufList, OSA_TIMEOUT_NONE);
    //timestamp = OSA_getCurGlobalTimeInUsec();
    //printf("TS %llu A15VpeLink_getFullBuffers called %d, got buffer %d %p\n",timestamp,status,pBufList->numBuf,pBufList->buffers[0]);
    if(status == SYSTEM_LINK_STATUS_SOK)
    {
        pObj->linkStats.getFullBufCount++;
    }
    return status;
}

/**
 *******************************************************************************
 *
 * \brief Callback function implemented by link to get empty buffers from next
 *        link.
 *
 * \param  ptr      [IN] Task Handle
 * \param  queId    [IN] queId from which buffers are required.
 * \param  pBufList [IN] Pointer to link information handle
 *
 * \return  SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
*/
Int32 A15VpeLink_putEmptyBuffers(Void * ptr, UInt16 queId,
                              System_BufferList * pBufList)
{
    UInt32 idx;
    UInt32 chId;
    OSA_TskHndl *pTsk = (OSA_TskHndl *) ptr;
    A15VpeLink_Obj *pObj = (A15VpeLink_Obj *) pTsk->appData;
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    A15VpeLink_ChObj *pChObj = pObj->chObj;
    vpe_params *vpe;	
    Int32 v4l2_index=-1;
    Int32 returnVal;
    System_Buffer    *pTmp=NULL;
   //UInt64 timestamp=0;
    
    OSA_assert(queId < A15_VPE_LINK_OUT_QUE_ID_MAX);
    OSA_assert(pBufList != NULL);
    OSA_assert(pBufList->numBuf <= SYSTEM_MAX_BUFFERS_IN_BUFFER_LIST);
    A15VpeLink_OutObj *pOutObj = &pObj->outObj[queId];

    pObj->linkStats.putEmptyBufCount++;
    //printf("A15VpeLink_putEmptyBuffers called number %d buffer %p channel %d\n", pBufList->numBuf,pBufList->buffers[0],pBufList->buffers[0]->chNum);
    for (idx = 0; idx < pBufList->numBuf; idx++)
    {
        chId = pBufList->buffers[idx]->chNum;
        OSA_assert(chId < A15_VPE_LINK_MAX_CH);
        //OSA_assert(OSA_ARRAYISVALIDENTRY(pBufList->buffers[idx],*pOutObj->buffers[chId]));
        status = OSA_quePut(&pOutObj->emptyBufQue[chId],
                              (Int32)pBufList->buffers[idx], OSA_TIMEOUT_NONE);
        OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
	 status = OSA_queGet(&pOutObj->emptyBufQue[chId],
                              (Int32 *)pTmp, OSA_TIMEOUT_FOREVER);
        OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
	 pChObj = &pObj->chObj[chId];
	 vpe = &pChObj->vpePrm;
	 returnVal = A15VpeLink_drvSearchMapTbl(&pChObj->outputBufMapTbl,NULL,NULL,&v4l2_index,pBufList->buffers[idx]);
	  if(returnVal != 1) //NOT found or error
	  {
	  	return SYSTEM_LINK_STATUS_EFAIL;
	  }
	A15VpeLink_drvOutputQbuf(vpe,v4l2_index);
	//printf("LINK %d: output QBUF %d %p\n",pObj->linkId, v4l2_index,pBufList->buffers[idx]);
	//timestamp = OSA_getCurGlobalTimeInUsec();

	//printf("TS %llu[LINK ID %d] A15VpeLink_putEmptyBuffers called number %d buffer %p channel %d\n", timestamp,pObj->linkId,pBufList->numBuf,pBufList->buffers[0],pBufList->buffers[0]->chNum);
    }

    return status;
}

/* Nothing beyond this point */

