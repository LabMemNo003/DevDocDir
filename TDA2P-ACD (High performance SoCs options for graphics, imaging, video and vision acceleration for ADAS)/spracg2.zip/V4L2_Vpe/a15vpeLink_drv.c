/*
 *******************************************************************************
 *
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 * ALL RIGHTS RESERVED
 *
 *******************************************************************************
 */

/**
 *******************************************************************************
 * \file vpeLink_drv.c
 *
 * \brief  This file has the implementation of VPE Link
 *
 *   VPE Link can be used to do processing on video input frames. These
 *   frames may be from capture or decoded video frames coming over network.
 *
 *   VPE can do
 *   - Color space conversion on input frames.
 *   - Color space conversion while outputting the frame to memory.
 *   - Scaling on input frames.
 *   - De-Interlacing, (conversion from field to frames )
 *
 *     The VPE link receives the input frames, submitted/queued them into VPS
 *     VPE driver along with a set of output frames to which the VPE driver
 *     write the de-interlaced/scaled output. once the processing is over
 *     the driver invoke a call back. On call back VPE Link reclaim these
 *     frames which are already processed and send back to the previous link.
 *     Also send out the output frames to the next link
 *
 *     VPE is validated only for DEI in Bypass mode (Bypass = TRUE).  This
 *     is because no HW set-up available currently to feed interlaced input
 *
 *     VPE link also supports the run time input and output resolution
 *     change - This feature is NOT verified in this version.
 *
 * \version 0.0 (Sept 2013) : [SS] First version
 *
 *******************************************************************************
*/

/*******************************************************************************
 *  INCLUDE FILES
 *******************************************************************************
 */
#include "a15vpeLink_priv.h"

/*******************************************************************************
 *  Defines
 *******************************************************************************
 */

/**
 *******************************************************************************
 *
 * \brief This function checks and updates SC crop parameters
 *
 *        compare the frame parameters with the previous configuration
 *        stored in the link object. Set the Flag rtPrmUpdate if there
 *        a change and invoke the RT param update functionality
 *
 * \param   pObj        [IN] VPE Link Instance handle
 * \param   chId        [IN] channel number
 * \param   rtPrmUpdate [IN] Flag to check rtPrmUpdate
 *
 * \return  SYSTEM_LINK_STATUS_SOK
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvUpdateScCropPrm(A15VpeLink_Obj * pObj, UInt32 chId,Bool rtPrmUpdate)
{
    A15VpeLink_ChObj *pChObj;
    System_LinkChInfo *pInQueChInfo;
    A15VpeLink_ChannelParams *chParams;
    System_CropConfig *scCropCfg;

    pChObj = &pObj->chObj[chId];
    pInQueChInfo = &pObj->inQueInfo.chInfo[chId];
    chParams = &pObj->createArgs.chParams[chId];

    scCropCfg = &chParams->scCropCfg;
    
    if ((scCropCfg->cropStartX) && (!rtPrmUpdate))
        pChObj->vpePrm.crop.c.top = scCropCfg->cropStartX;
    else
        pChObj->vpePrm.crop.c.top = pInQueChInfo->startX;
    
    if ((scCropCfg->cropWidth) && (!rtPrmUpdate))
        pChObj->vpePrm.crop.c.width = scCropCfg->cropWidth;
    else
        pChObj->vpePrm.crop.c.width = pInQueChInfo->width;
    
    if ((scCropCfg->cropStartY) && (!rtPrmUpdate))
        pChObj->vpePrm.crop.c.left = scCropCfg->cropStartY;
    else
        pChObj->vpePrm.crop.c.left = pInQueChInfo->startY;
    
    if ((scCropCfg->cropHeight) && (!rtPrmUpdate))
        pChObj->vpePrm.crop.c.height = scCropCfg->cropHeight;
    else
        pChObj->vpePrm.crop.c.height = pInQueChInfo->height;
    
    if (SYSTEM_LINK_CH_INFO_GET_FLAG_SCAN_FORMAT(pInQueChInfo->flags) ==
                                                 SYSTEM_SF_INTERLACED &&
        !pObj->createArgs.chParams[chId].deiCfg.bypass)
    {
        pChObj->vpePrm.crop.c.top *= 2;
        pChObj->vpePrm.crop.c.height *= 2;
    }
    
    pChObj->vpePrm.crop.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;


    return SYSTEM_LINK_STATUS_SOK;
}


/**
 *******************************************************************************
 *
 * \brief Function to create the VPE link channel object
 *
 *        Create the VPE link channel object, one per input channel
 *        - Create the intermediate buffer queue per channel
 *        - Create the intermediate Fvid2 frame freeQ
 *        - Updates the create time SC crop parameters
 *        - Populates the VPS driver create and control parameters
 *
 * \param   pObj     [IN] VPE Link Instance handle
 * \param   chId     [IN] channel number
 *
 * \return  SYSTEM_LINK_STATUS_SOK
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvCreateChObj(A15VpeLink_Obj * pObj, UInt32 chId)
{
    A15VpeLink_ChObj *pChObj;
    System_LinkChInfo *pInChInfo;
    System_LinkChInfo *pOutChInfo;
    vpe_params *pDrvChParams;
    image_params *pFormat;
    A15VpeLink_ChannelParams *chParams;
    Int32 i;
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    System_Buffer    *pTmp=NULL;
	
    OSA_assert(chId < pObj->inQueInfo.numCh);
    pChObj = &pObj->chObj[chId];
    chParams = &pObj->createArgs.chParams[chId];

    pChObj->nextFid = 0;

    pInChInfo = &pObj->inQueInfo.chInfo[chId];
	
    A15VpeLink_drvOpen(pChObj);

    pDrvChParams = &pChObj->vpePrm;

    pDrvChParams->chNum = chId;

    pFormat = &pDrvChParams->src;

    pFormat->width = pInChInfo->width;
    pFormat->height = pInChInfo->height;

    A15VpeLink_drvDescribeFormat(SYSTEM_LINK_CH_INFO_GET_FLAG_DATA_FORMAT(pInChInfo->flags),pFormat);

    OSA_resetSkipBufContext(
        &pChObj->frameSkipCtx,
        chParams->outParams[0].inputFrameRate,
        chParams->outParams[0].outputFrameRate
        );
    
    
    //pChObj->enableOut = FALSE;
    if (TRUE == pObj->createArgs.enableOut[0])
    {
        pChObj->enableOut = TRUE;
    
        pOutChInfo = &pObj->info.queInfo[0].chInfo[chId];
    
        /* initialize the rtparm output resolution from outObj */
        pChObj->chRtOutInfoUpdate = FALSE;
        pChObj->chRtEnableOutQFlag = FALSE;
        pChObj->chRtOutInfoUpdateWhileDrop = A15_VPE_LINK_OUT_QUE_ID_MAX;
    
    
        pFormat = &pDrvChParams->dst;
    
        pFormat->height = chParams->outParams[0].height;
        pFormat->width = OSA_floor(chParams->outParams[0].width, 16);
     			
        printf("A15VpeLink_drvCreateChObj DEST is width %d height %d\n", pFormat->width, pFormat->height);
        A15VpeLink_drvDescribeFormat(chParams->outParams[0].dataFormat,pFormat);
    	
        //pFormat->pitch[0] =OSA_align(pFormat->width, 16);
        pOutChInfo->startX = 0;
        pOutChInfo->startY = 0;
        //SYSTEM_LINK_CH_INFO_SET_FLAG_SCAN_FORMAT(pOutChInfo->flags,pFormat->scanFormat);
    
        pOutChInfo->width = chParams->outParams[0].width;
        pOutChInfo->height = chParams->outParams[0].height;
        pOutChInfo->pitch[0] = chParams->outParams[0].width;
        pOutChInfo->pitch[1] = chParams->outParams[0].width;
        pOutChInfo->pitch[2] = 0;
        SYSTEM_LINK_CH_INFO_SET_FLAG_DATA_FORMAT(pOutChInfo->flags,chParams->outParams[0].dataFormat);
    
    }


    A15VpeLink_drvUpdateScCropPrm(pObj, chId, FALSE);
    if(chParams->deiCfg.bypass == FALSE)
    {
	   pDrvChParams->deint = 1;/*always V4L2_FIELD_ALTERNATE*/
	   pDrvChParams->field = V4L2_FIELD_ALTERNATE;
    }
    else
    {
    	   pDrvChParams->deint = 0;
	   pDrvChParams->field = V4L2_FIELD_NONE;
    }
	
    pDrvChParams->translen = A15VPE_LINK_DEFAULT_TRANSLEN;

    A15VpeLink_drvInputInit(pChObj);
        
    A15VpeLink_drvOutputInit(pObj);
    
    for (i = 0; i < NUMBUF; i++)
    {
    	 status = OSA_queGet(&pObj->outObj->emptyBufQue[chId],(Int32 *)pTmp, OSA_TIMEOUT_FOREVER);
        OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
        A15VpeLink_drvOutputQbuf(pDrvChParams, i);
    }
    /*************************************
            Data is ready Now
    *************************************/
    
    A15VpeLink_drvStreamOn(pDrvChParams->fd, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);

    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief This function submit the job to the VPS driver
 *
 *        VPS driver defines certain input and output frame data structure
 *        and this need to be populated to submit any job to the driver
 *        - Call VpeLink_drvQueueFramesToChQue to put the input buffers
 *          into the link internal input buffer queue
 *        - Get the input frame list
 *        - Get the output frame List
 *        - Populate VPS driver the process List
 *        - Call the function to create the in/out frame List
 *        - Call IOCTL if useOverridePrevFldBuf == TRUE
 *        - Submit the job to driver by invoking FVID2_processFrames
 *        - Wait for the process/job completion
 *        - Call FVID2_getProcessedFrames once the completion
 *        Repeat above until all input frames are processed
 *
 * \param   pObj   [IN]  VPE Link Instance handle
 *
 * \param   status [OUT] Return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvProcessData(A15VpeLink_Obj * pObj)
{
    //A15VpeLink_ChObj *pChObj = &pObj->chObj[0];
    //vpe_params *vpe = &pChObj->vpePrm;
    //Int32 index=0,i,count=0;

    if(pObj->isFirstFrameRecv==FALSE)
    {
        pObj->isFirstFrameRecv = TRUE;

        OSA_resetLinkStatistics(
                &pObj->linkStats,
                pObj->inQueInfo.numCh,
                A15_VPE_LINK_OUT_QUE_ID_MAX);

        OSA_resetLatency(&pObj->linkLatency);
        OSA_resetLatency(&pObj->srcToLinkLatency);
    }

    pObj->linkStats.newDataCmdCount++;
    //printf("A15VpeLink_drvProcessData \n");
    A15VpeLink_drvQueueFramesToChQue(pObj);

    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief Function to create the VPE link output object
 *
 *        Create the VPE link Output object, one per output queue
 *        - Create the Output Buffer Queue
 *        - populates the output frame parameters
 *        - Allocate the memory for the output frame buffers
 *        - Creates the output FVID2 frames and populaces with frame pointers
 *
 * \param   pObj     [IN] VPE Link Instance handle
 *
 * \return  status   [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvCreateOutObj(A15VpeLink_Obj * pObj)
{
    A15VpeLink_OutObj *pOutObj;
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    UInt32 outId, chId;
    A15VpeLink_ChannelParams *chParams;
    UInt32		size=1280*720*12/8,i;
    System_Buffer	*pSysBuf=NULL;
    System_VideoFrameBuffer  *pVideoFrame=NULL;	
    void*		pFrameData=NULL;
    A15VpeLink_ChObj *pChObj;
    image_params image;
    System_LinkChInfo *pbufInfo=NULL;
    Int32 handle_dmabuf=0,handle_dmabuf_uv=0;
	
    pObj->info.numQue = A15_VPE_LINK_OUT_QUE_ID_MAX;
    printf("A15VpeLink_drvCreateOutObj pObj->inQueInfo.numCh %d \n",pObj->inQueInfo.numCh);
    for (outId = 0u; outId < A15_VPE_LINK_OUT_QUE_ID_MAX; outId++)
    {
        pObj->info.queInfo[outId].numCh = 1;
        if (TRUE == pObj->createArgs.enableOut[outId])
        {
            pObj->info.queInfo[outId].numCh = pObj->inQueInfo.numCh;
        }
    }

    for (outId = 0u; outId < A15_VPE_LINK_OUT_QUE_ID_MAX; outId++)
    {
        if (pObj->createArgs.enableOut[outId])
        {
            pOutObj = &pObj->outObj[outId];

            status = OSA_bufCreate(&pOutObj->bufOutQue, TRUE, FALSE);
            OSA_assert(status == SYSTEM_LINK_STATUS_SOK);

            memset(pOutObj->numFrames, 0, sizeof(pOutObj->numFrames));

            for (chId = 0u; chId < pObj->inQueInfo.numCh; chId++)
            {
            	  pChObj =  &pObj->chObj[chId];
                chParams = &pObj->createArgs.chParams[chId];
                if ((chParams->outParams[outId].numBufsPerCh <= 0) ||
                    (chParams->outParams[outId].numBufsPerCh > A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH))
                {
                    chParams->outParams[outId].numBufsPerCh =
                                               A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH;
                }
                OSA_assert(chParams->outParams[outId].numBufsPerCh <=
                                       A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH);
			
                pOutObj->numFrames[chId] = chParams->outParams[outId].numBufsPerCh;
		  status = OSA_queCreate(&pOutObj->emptyBufQue[chId],
                                     pOutObj->numFrames[chId]);
                OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
		  //printf("A15VpeLink_drvCreateOutObj prepare to call OSA_memAllocSR %d\n",pOutObj->numFrames[chId]);		
		  for(i=0;i<pOutObj->numFrames[chId];i++)
		  {
		  	image.width = chParams->outParams[outId].width;
			image.height =chParams->outParams[outId].height; 	
		  	A15VpeLink_drvDescribeFormat( chParams->outParams[outId].dataFormat,&image);
		       size = image.size+image.size_uv;
                	pSysBuf = (System_Buffer *)OSA_memAllocSR(OSA_HEAPID_DDR_CACHED_SR1,size+sizeof(System_Buffer)+sizeof(System_VideoFrameBuffer),0);
			//printf("OSA_memAllocSR got frame buffer physical address %p size %d\n",pSysBuf,size+sizeof(System_Buffer)+sizeof(System_VideoFrameBuffer));		
		  	OSA_assert(pSysBuf);
		  	//convernt it to vitual address
		  	pSysBuf = (System_Buffer *)OSA_memPhys2Virt((UInt32)pSysBuf,OSA_HEAPID_DDR_CACHED_SR1);
			printf("A15VpeLink_drvCreateOutObj convert frame buffer virtual address %p\n",pSysBuf);
			pVideoFrame = (System_VideoFrameBuffer *)((UInt8 *)pSysBuf + sizeof(System_Buffer));
			pFrameData = (void *)((UInt8 *)pVideoFrame + sizeof(System_VideoFrameBuffer));
			memset(pSysBuf, 0, sizeof(System_Buffer));
                     memset(pVideoFrame, 0, sizeof(System_VideoFrameBuffer));

	              pSysBuf->bufType      = SYSTEM_BUFFER_TYPE_VIDEO_FRAME;
	              pSysBuf->chNum        = chId;
	              pSysBuf->payloadSize  = sizeof(System_VideoFrameBuffer);
	              pSysBuf->payload      = pVideoFrame;

			pVideoFrame->bufAddr[0] = pFrameData;//Y
			if(image.coplanar)
				pVideoFrame->bufAddr[1] = pFrameData+image.size;//UV
				
			pbufInfo = &pVideoFrame->chInfo;
			memset(pbufInfo,0,sizeof(System_LinkChInfo));
			pbufInfo->width = image.width;
			pbufInfo->height = image.height;
			SYSTEM_LINK_CH_INFO_SET_FLAG_DATA_FORMAT(pbufInfo->flags,chParams->outParams[outId].dataFormat);
			
			pOutObj->buffers[chId][i] = pSysBuf;

			status = OSA_quePut(&pOutObj->emptyBufQue[chId],
                               (Int32)pOutObj->buffers[chId][i], OSA_TIMEOUT_NONE);
                	OSA_assert(status == SYSTEM_LINK_STATUS_SOK);

			status =A15VpeLink_drvConstructDmabuf(pObj->drmFd,&handle_dmabuf,&handle_dmabuf_uv,&pChObj->vpePrm.output_buf_dmafd[i],&pChObj->vpePrm.output_buf_dmafd_uv[i],pSysBuf);
			OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
			A15VpeLink_drvAddMapItem(&pChObj->outputBufMapTbl,handle_dmabuf,handle_dmabuf_uv,pChObj->vpePrm.output_buf_dmafd[i],pChObj->vpePrm.output_buf_dmafd_uv[i],NULL,pSysBuf);
		  }
            	}
        }
    }

    return (status);
}

/**
 *******************************************************************************
 *
 * \brief VPE link create function
 *
 *        This Set the Link and driver create time parameters.
 *        - Get the channel info from previous link
 *        - create the semaphore required for VPE link
 *        - Set the internal data structures
 *        - Create the output object per output queue
 *        - Create the Link channel object per channel
 *        - Create the VPE driver instance
 *        - Allocate the DEI context buffers
 *        - Choose the scalar coefficients and configure the driver
 *        - Create the link intermediate request object
 *
 * \param   pObj     [IN] VPE Link Instance handle
 * \param   pPrm     [IN] VPE link create parameters
 *                        This need to be configured by the application
 *
 * \return  SYSTEM_LINK_STATUS_SOK
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvCreate(A15VpeLink_Obj * pObj, A15VpeLink_CreateParams * pPrm)
{
    UInt32 chId;
    Int32 status;
    Int8 devname[20] = "/dev/dri/card0";
    //Int8 ret;
	
    memcpy(&pObj->createArgs, pPrm, sizeof(*pPrm));

    status = System_linkGetInfo(pPrm->inQueParams.prevLinkId, &pObj->inTskInfo);
    OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
    OSA_assert(pPrm->inQueParams.prevLinkQueId < pObj->inTskInfo.numQue);

    memcpy(&pObj->inQueInfo,
           &pObj->inTskInfo.queInfo[pPrm->inQueParams.prevLinkQueId],
           sizeof(pObj->inQueInfo));
    OSA_assert(pObj->inQueInfo.numCh <= A15_VPE_LINK_MAX_CH);
    //test deinterlace with simulation
    if(pObj->createArgs.chParams[0].deiCfg.bypass == FALSE)
    {
    	printf("A15VpeLink DEINTERLACE!!! \n");
    	//pObj->inQueInfo.chInfo[0].height = pObj->inQueInfo.chInfo[0].height/2;
    }
    pObj->useOverridePrevFldBuf = FALSE;

    pObj->givenInFrames = 0x0;
    pObj->returnedInFrames = 0x0;
    pObj->loadUpsampleCoeffs = FALSE;
    pObj->isStopSupported = FALSE;

    pObj->drmFd = open (devname, O_RDWR | O_CLOEXEC);
    OSA_assert(pObj->drmFd > 0);
    printf("A15VpeLink_drvCreate open DRM fd %d\n",pObj->drmFd);
/*
    //if infoADAS need comment
    ret = drmIoctl(pObj->drmFd, DRM_IOCTL_DROP_MASTER,NULL);
    if(ret)
    {
        printf("Call drmIoctl DRM_IOCTL_DROP_MASTER failed %d\n",ret);
    	 return SYSTEM_LINK_STATUS_EFAIL;
    }*/
    A15VpeLink_drvCreateOutObj(pObj);

    for (chId = 0; chId < pObj->inQueInfo.numCh; chId++)
    {
        A15VpeLink_drvCreateChObj(pObj, chId);
    }

    OSA_resetLatency(&pObj->linkLatency);
    OSA_resetLatency(&pObj->srcToLinkLatency);

    OSA_resetLinkStatistics(
                &pObj->linkStats,
                pObj->inQueInfo.numCh,
                A15_VPE_LINK_OUT_QUE_ID_MAX);

    pObj->isFirstFrameRecv = FALSE;
	
    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief Function to stop the VPE link
 *
 *        - Invoke the VPS driver stop (FVID2_stop)
 *        - Call VpeLink_drvGetProcessedData if any request pending
 *        - Release context fields if any held inside the driver
 *
 * \param   pObj     [IN] VPE Link Instance handle
 *
 * \return  rtnValue [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvStop(A15VpeLink_Obj * pObj)
{
    Int32 rtnValue = SYSTEM_LINK_STATUS_SOK;
    A15VpeLink_ChObj *pChObj = pObj->chObj;	
    vpe_params *vpe = &pChObj->vpePrm;
    UInt32		i=0,status;
    Int32		v4l2_index=0;
    System_Buffer *pSysBuf=NULL;
    System_BufferList bufListToPre;
	
#ifdef SYSTEM_DEBUG_VPE
    Vps_printf(" VPE: Stop in progress !!!\n");
#endif

    if (TRUE == pObj->isStopSupported)
    {
	A15VpeLink_drvStreamOff(vpe->fd, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
	A15VpeLink_drvStreamOff(vpe->fd, V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE);

        if (vpe->deint) 
        {
           	while(i<2)// 3 frames 0,1, 2
           	{
           		v4l2_index = A15VpeLink_drvInputDqbuf(vpe);
			OSA_assert(v4l2_index < NUMBUF);

           		status = A15VpeLink_drvGetSysBufFromMapTbl(&pChObj->inputBufMapTbl,v4l2_index,&pSysBuf);
           		OSA_assert(status == SYSTEM_LINK_STATUS_SOK);

           		bufListToPre.numBuf = 0x01u;
           		bufListToPre.buffers[0] = pSysBuf;
               	pObj->returnedInFrames++;
           
   			System_putLinksEmptyBuffers(pObj->createArgs.inQueParams.prevLinkId,
                               pObj->createArgs.inQueParams.prevLinkQueId,
                               &bufListToPre);
			i++;
           	}
        }
        if (rtnValue != SYSTEM_LINK_STATUS_SOK)
        {
#ifdef SYSTEM_DEBUG_VPE
            Vps_printf(" VPE: Stop ERROR !!!\n");
#endif
        }
    }

#ifdef SYSTEM_DEBUG_VPE
    Vps_printf(" VPE: Stop Done !!!\n");
#endif

    return (rtnValue);
}

/**
 *******************************************************************************
 *
 * \brief Function to Delete the VPE link
 *
 *        - Free-up the DEI context buffers
 *        - Delete the VPE driver (FVID2_delete)
 *        - Delete the Link "process complete" semaphore
 *        - Remove the output buffer queue
 *        - De-allocate the output video frame memory
 *        - Delete the output buffer empty buffer queue
 *        - Delete the FVID2_frame freeQ
 *        - Delete the Link intermediate channel specific input queue
 *        - Delete the link internal request object queue
 *
 * \param   pObj     [IN] VPE Link Instance handle
 *
 * \return  rtnValue [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvDelete(A15VpeLink_Obj * pObj)
{
    UInt32 outId, chId;
    A15VpeLink_OutObj *pOutObj;
    UInt32		size=0,i;
    image_params image;
    A15VpeLink_ChannelParams *chParams;

    A15VpeLink_drvClose(pObj);
	
    for (outId = 0; outId < A15_VPE_LINK_OUT_QUE_ID_MAX; outId++)
    {
        if (pObj->createArgs.enableOut[outId])
        {
            pOutObj = &pObj->outObj[outId];

            OSA_bufDelete(&pOutObj->bufOutQue);
            for (chId = 0; chId < pObj->inQueInfo.numCh; chId++)
            {
                if (pOutObj->numFrames[chId] > 0)
                {
                     chParams = &pObj->createArgs.chParams[chId];
                	image.width = chParams->outParams[outId].width;
			image.height =chParams->outParams[outId].height; 	
		  	A15VpeLink_drvDescribeFormat( chParams->outParams[outId].dataFormat,&image);
		       size = image.size+image.size_uv;
			for(i=0;i<pOutObj->numFrames[chId];i++)
			{
		            //printf("A15VpeLink_drvDelete: free %p size %d\n",(Ptr)OSA_memVirt2Phys((UInt32)pOutObj->buffers[chId][i],OSA_MEM_REGION_TYPE_SR1),size+sizeof(System_Buffer)+sizeof(System_VideoFrameBuffer));
                          OSA_memFreeSR(
                          OSA_HEAPID_DDR_CACHED_SR1,
                          (Ptr)OSA_memVirt2Phys((UInt32)pOutObj->buffers[chId][i],OSA_MEM_REGION_TYPE_SR1),
                          size+sizeof(System_Buffer)+sizeof(System_VideoFrameBuffer));
			}
                }
            }
            A15VpeLink_drvDeleteVpeOutChBufferQueue(pObj, outId);
        }
    }

    return SYSTEM_LINK_STATUS_SOK;
}
/**
 *******************************************************************************
 *
 * \brief Function to prints the VPE link statistics
 *
 *        Also reset the Link statistics after the print controlled by a flag
 *
 * \param   pObj            [IN] Display Link Instance handle
 * \param   resetAfterPrint [IN] Flag to reset the statistics after print
 *
 * \return  SYSTEM_LINK_STATUS_SOK
 *
 *******************************************************************************
 */
Int32 A15VpeLink_printStatistics (A15VpeLink_Obj *pObj, Bool resetAfterPrint)
{
    OSA_printLinkStatistics(&pObj->linkStats, "VPE", TRUE);

    OSA_printLatency("VPE",
                       &pObj->linkLatency,
                       &pObj->srcToLinkLatency,
                        TRUE
                       );

    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief Function to prints the VPE link output buffer status
 *
 * \param   pObj            [IN] Display Link Instance handle
 *
 * \return  SYSTEM_LINK_STATUS_SOK
 *
 *******************************************************************************
 */
Int32 A15VpeLink_printBufferStatus(A15VpeLink_Obj * pObj)
{
    Int32 i;
    UInt8 str[32];

    for (i=0; i<A15_VPE_LINK_OUT_QUE_ID_MAX; i++)
    {
        sprintf ((char *)str, "VPE OUT%d", i);
        OSA_bufPrintStatus(str, &pObj->outObj[i].bufOutQue);
    }

    return SYSTEM_LINK_STATUS_SOK;
}

