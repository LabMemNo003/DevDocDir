/*
 *******************************************************************************
 *
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 * ALL RIGHTS RESERVED
 *
 *******************************************************************************
 */

/**
 *******************************************************************************
 *
 * \ingroup VPE_LINK_API
 * \defgroup VPE_LINK_IMPL VPE Link Implementation
 *
 * @{
 */

/**
 *******************************************************************************
 *
 * \file vpeLink_priv.h VPE Link private API/Data structures
 *
 * \brief  This link private header file has defined
 *         - VPE link instance/handle object
 *         - All the local data structures
 *         - VPE BSP driver interfaces
 *
 * \version 0.0 (Sept 2013) : [SS] First version
 *
 *******************************************************************************
 */

#ifndef _VPE_LINK_PRIV_H_
#define _VPE_LINK_PRIV_H_

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
 *  Include files
 *******************************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <linux/videodev2.h>
#include <linux/v4l2-controls.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <xf86drm.h>
#include <omap_drm.h>
#include <omap_drmif.h>

#include <include/link_api/system.h>
#include <linux/src/system/system_priv_common.h>
#include <osa.h>
#include <osa_mutex.h>
#include <osa_que.h>
#include <osa_buf.h>
#include <osa_prf.h>
#include <osa_mem.h>

#include <include/link_api/a15vpeLink.h>


/*******************************************************************************
 *  Defines
 *******************************************************************************
 */

/**
 *******************************************************************************
 *
 *   \brief Max Number of VPE link instances supported
 *
 *   SUPPORTED in ALL platforms
 *
 *******************************************************************************
 */
#define A15_VPE_LINK_OBJ_MAX                     (4)
/**
 *******************************************************************************
 * \brief size of A15 VPE link thread stack
 *******************************************************************************
 */
#define A15_VPE_LINK_TSK_STACK_SIZE (OSA_TSK_STACK_SIZE_DEFAULT)
/**
 *******************************************************************************
 *
 *   \brief Define the Max Number of output buffers per channel of VPE link
 *
 *   SUPPORTED in ALL platforms
 *
 *******************************************************************************
 */
#define A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH       (10)
#define A15_VPE_LINK_MAX_MAP_TBL_ITEM_PER_CH       (A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH)

#define V4L2_CID_TRANS_NUM_BUFS         (V4L2_CID_PRIVATE_BASE)
#define A15VPE_LINK_DEFAULT_TRANSLEN			1
#define NUMBUF                          A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH

/*******************************************************************************
 *  Data structures
 *******************************************************************************
 */
#define pexit(fmt, arg...) { \
		printf(fmt, ## arg); \
		exit(SYSTEM_LINK_STATUS_EFAIL); \
}

//#define vpe_debug

#ifdef vpe_debug
#define dprintf(fmt, arg...) printf(fmt, ## arg)
#else
#define dprintf(fmt, arg...) do {} while(0)
#endif


typedef struct  {
	UInt32 width;
	UInt32 height;
	UInt32 fourcc;
	UInt32 size;
	UInt32 size_uv;
	UInt32 coplanar;
	enum v4l2_colorspace colorspace;
	UInt32 numbuf;
}image_params;

typedef struct {
	UInt32 chNum;
	UInt32 fd;
	UInt32 field;
	UInt32 deint;
	UInt32 translen;
	image_params src;
	image_params dst;
	struct  v4l2_crop crop;

	UInt32 input_buf_quantity;
	
	UInt32 input_buf_num;
	Int32 input_buf_dmafd[NUMBUF];
	Int32 input_buf_dmafd_uv[NUMBUF];

	UInt32 output_buf_num;
	Int32 output_buf_dmafd[NUMBUF];
	Int32 output_buf_dmafd_uv[NUMBUF];
	
}vpe_params;

typedef struct {
	System_Buffer			*header;
	void						*buf; /*meta data buffer[0]*/
	UInt32					v4l2_index;

	Int32					handle_dma_buf_fd;
	Int32					handle_dma_buf_fd_uv;
	
	Int32					dma_buf_fd;
	Int32					dma_buf_fd_uv;
	UInt32					field_id;
}A15vpelink_map_item;

typedef struct {
	UInt32 itemNum;
	A15vpelink_map_item	item[A15_VPE_LINK_MAX_MAP_TBL_ITEM_PER_CH];
}A15vpelink_map_tbl;
/**
 *******************************************************************************
 *
 *   \brief Data Structure for the VPE link Output object
 *
 *          This includes the output side
 *          - Queues
 *          - System buffers
 *          - FVID2 frames
 *
 *******************************************************************************
*/
typedef struct {
    OSA_BufHndl bufOutQue;

    System_Buffer *buffers[A15_VPE_LINK_MAX_CH][A15_VPE_LINK_MAX_OUT_FRAMES_PER_CH];
    /**< System buffer data structure to exchange buffers between links */
    /**< Payload for System buffers */
    UInt32 numFrames[A15_VPE_LINK_MAX_CH];
    /**< Number of output buffers per channel */
    OSA_QueHndl emptyBufQue[A15_VPE_LINK_MAX_CH];
    /**< VPE link output side empty buffer queue */
} A15VpeLink_OutObj;

/**
 *******************************************************************************
 *
 *   \brief Data Structure for the VPE link Input side object
 *
 *          This includes the Input side FVID2 free Queues
 *          and the FVID2 frames
 *
 *******************************************************************************
*/
typedef struct {
    OSA_QueHndl fvidFrameQueue;
} A15VpeLink_InObj;

/**
 *******************************************************************************
 *
 *   \brief VPE link Channel specific instance object
 *
 *          This structure contains
 *          - All the channel specific local data structures
 *          - VPS/BSP Data structures required for VPE BSP driver interfaces
 *          - All fields to support the CH vise stats and status information
 *
 *******************************************************************************
*/
typedef struct {
    Bool enableOut;
    /**< Output Queue enable/disable flag */
    UInt32 nextFid;
	
    vpe_params vpePrm;

    Bool chRtOutInfoUpdate;
    /**< flag is check the RT param update */
    Bool chRtEnableOutQFlag;
    /**< Flag is check alternative/fid vise output QueueID update */
    UInt32 chRtOutInfoUpdateWhileDrop;
    /**< Queue ID to check whether RT update required while frame drop */

    OSA_BufSkipContext frameSkipCtx;
    /**< Data structure for frame skip to achieve expected output frame rate */

    A15VpeLink_InObj inObj;
    /**< VPE link Input side object, for FVID2 freeQ and frame */
    UInt32 streaming;  /*do once flag for V4L2 processing*/
	
    A15vpelink_map_tbl	inputBufMapTbl;
    A15vpelink_map_tbl	outputBufMapTbl;

} A15VpeLink_ChObj;

/**
 *******************************************************************************
 *
 *   \brief Data Structure for VPE request object,
 *          This is for the Link internal, and is the object hold all the
 *          required informations to invoking the BSP driver processing call
 *
 *******************************************************************************
*/
typedef struct {
    /**< Output frame list, to hold the output frames */
    UInt32 outListQueIdMap[A15_VPE_LINK_MAX_CH];

} A15VpeLink_ReqObj;

/**
 *******************************************************************************
 *
 *   \brief VPE link instance object
 *
 *          This structure contains
 *          - All the local data structures
 *          - VPS/BSP Data structures required for VPE BSP driver interfaces
 *          - All fields to support the Link stats and status information
 *
 *******************************************************************************
*/
typedef struct {
    UInt32 linkId;
    /**< placeholder to store the link task Id */
    char name[32];
    /**< Link name */
    OSA_TskHndl tsk;
    /**< placeholder to store the link task handler */
    A15VpeLink_CreateParams createArgs;
    /**< VPE link create time parameters */
    System_LinkInfo inTskInfo;
    /**< Specifies a place holder that describe the LINK information */
    System_LinkQueInfo inQueInfo;
    /**< Input Q channel specific info, read from the outQ of previous LINK */
    A15VpeLink_ReqObj reqObj;
    /**< Link internal data structure, object hold all the required
     *   informations to invoking the BSP driver processing call */
	
    A15VpeLink_OutObj outObj[A15_VPE_LINK_OUT_QUE_ID_MAX];
    /**<  Data Structure to hold the VPE link Output object*/
    System_LinkInfo info;
    /**< VPE link output queue info, the next link query & use this info */
    UInt32 isStopSupported;
    /**< VPS error process list */
    A15VpeLink_ChObj chObj[A15_VPE_LINK_MAX_CH];

    /**< Semaphore for the VPE process complete */
    UInt32 givenInFrames;
    /**< Number of frames given to the driver */
    UInt32 returnedInFrames;
    /**< Number of frames returned by the driver, This is required because
     *   Even though all the requests are addressed, the driver would have held
     *   back couple of input fields as context fields, use this to get them */
    Bool loadUpsampleCoeffs;
    /**< Flag to load the up scaling coefficients */

    UInt32 useOverridePrevFldBuf;
    /**< flag to enable "override previous field buf" mode
     *   Currently set to FALSE inside the Link and not exposed as LINK API */

    OSA_LatencyStats  linkLatency;
    /**< Structure to find out min, max and average latency of the link */

    OSA_LatencyStats  srcToLinkLatency;
    /**< Structure to find out min, max and average latency from
     *   source to this link
     */

    OSA_LinkStatistics    linkStats;
    /**< links statistics like frames captured, dropped etc */

    Bool isFirstFrameRecv;
    /**< Flag to indicate if first frame is received, this is used as trigger
     *   to start stats counting
     */
    Int32 	drmFd;
} A15VpeLink_Obj;

/*******************************************************************************
 *  VPE Link Private Functions
 *******************************************************************************
 */
Int32 A15VpeLink_getLinkInfo(Void * pTsk, System_LinkInfo * info);
Int32 A15VpeLink_getFullBuffers(Void * ptr, UInt16 queId,
                             System_BufferList * pBufList);
Int32 A15VpeLink_putEmptyBuffers(Void * ptr, UInt16 queId,
                              System_BufferList * pBufList);
Int32 A15VpeLink_drvCreate(A15VpeLink_Obj * pObj, A15VpeLink_CreateParams * pPrm);
Int32 A15VpeLink_drvProcessData(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvGetProcessedData(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvStop(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvDelete(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvSetChannelInfo(A15VpeLink_Obj * pObj, A15VpeLink_ChannelInfo *channelInfo);
Int32 A15VpeLink_drvSetFrameRate(A15VpeLink_Obj * pObj, A15VpeLink_ChFpsParams * params);
Int32 A15VpeLink_printStatistics (A15VpeLink_Obj *pObj, Bool resetAfterPrint);
Int32 A15VpeLink_printBufferStatus(A15VpeLink_Obj * pObj);
Int32  A15VpeLink_drvClose(A15VpeLink_Obj *pObj);
Int32 A15VpeLink_drvOpen(A15VpeLink_ChObj *pChObj);
Int32 A15VpeLink_drvGetSysBufFromMapTbl(A15vpelink_map_tbl *mapTbl,UInt32 v4l2_index,System_Buffer **pBuffer);

Int32 A15VpeLink_drvConstructDmabuf(Int32 drm_fd,Int32 *handle_buf_dmafd,Int32 *handle_uv_buf_dmafd,Int32 *buf_dmafd,Int32 *uv_buf_dmafd,System_Buffer *pBuffer);
Int32 A15VpeLink_drvDeleteVpeOutChBufferQueue (A15VpeLink_Obj * pObj, UInt32 outId);
Int32 A15VpeLink_drvSearchMapTbl(A15vpelink_map_tbl *mapTbl,Int32 *buf_dmafd,Int32 *uv_buf_dmafd,Int32 *v4l2_index,System_Buffer *pBuffer);
Int32 A15VpeLink_drvAddMapItem(A15vpelink_map_tbl *mapTbl,Int32 handle_buf_dmafd,Int32 handle_uv_buf_dmafd,Int32 buf_dmafd,Int32 uv_buf_dmafd,Int32 *v4l2_index,System_Buffer *pBuffer);

Int32 A15VpeLink_drvCreateChObj(A15VpeLink_Obj * pObj, UInt32 chId);
Int32 A15VpeLink_drvQueueFramesToChQue(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvAllocCtxMem(A15VpeLink_Obj * pObj);
Int32 A15VpeLink_drvSetScCoeffs(A15VpeLink_ChObj * pObj);
Int32 A15VpeLink_drvUpdateScCropPrm(A15VpeLink_Obj * pObj, UInt32 chId,Bool rtPrmUpdate);
Int32  A15VpeLink_drvInputInit(A15VpeLink_ChObj *pChObj);
Int32  A15VpeLink_drvOutputInit(A15VpeLink_Obj * pObj);
Int32  A15VpeLink_drvInputQbuf(vpe_params *vpe, Int32 index,UInt64 timestamp);
Int32  A15VpeLink_drvInputDqbuf(vpe_params *vpe);
Int32  A15VpeLink_drvOutputQbuf(vpe_params *vpe, Int32 index);
Int32  A15VpeLink_drvOutputDqbuf(vpe_params *vpe,UInt64 *timestamp);

Int32  A15VpeLink_drvStreamOn(Int32 fd, Int32 type);
Int32  A15VpeLink_drvStreamOff(Int32 fd, Int32 type);

Int32  A15VpeLink_drvDescribeFormat (System_VideoDataFormat format, image_params *image);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

/*@}*/

/* Nothing beyond this point */
