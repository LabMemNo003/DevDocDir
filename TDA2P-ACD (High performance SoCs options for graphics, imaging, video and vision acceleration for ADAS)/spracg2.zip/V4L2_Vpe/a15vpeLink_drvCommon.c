/*
 *******************************************************************************
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 * ALL RIGHTS RESERVED
 *
 *******************************************************************************
 */

/**
 *******************************************************************************
 * \file a15vpeLink_drvCommon.c
 *
 * \brief  This file has the implementation of VPE Link
 *
 *   VPE Link can be used to do processing on video input frames. These
 *   frames may be from capture or decoded video frames coming over network.
 *   Video processing capability is present on several sub systems (VPE, ISS, DSS etc) in the SOC.
 *   Code which is common across sub systems is placed in this file.
 *
 *   VPE can do
 *   - Color space conversion on input frames.
 *   - Color space conversion while outputting the frame to memory.
 *   - Scaling on input frames.
 *   - De-Interlacing, (conversion from field to frames )
 *
 *     The VPE link receives the input frames, submitted/queued them into VPS
 *     VPE driver along with a set of output frames to which the VPE driver
 *     write the de-interlaced/scaled output. once the processing is over
 *     the driver invoke a call back. On call back VPE Link reclaim these
 *     frames which are already processed and send back to the previous link.
 *     Also send out the output frames to the next link
 *
 *     VPE is validated only for DEI in Bypass mode (Bypass = TRUE).  This
 *     is because no HW set-up available currently to feed interlaced input
 *
 *     VPE link also supports the run time input and output resolution
 *     change - This feature is NOT verified in this version.
 *
 * \version 0.0 (Nov 2014) : [PS] Created First version from existing VPE link
 *
 *******************************************************************************
*/

/*******************************************************************************
 *  INCLUDE FILES
 *******************************************************************************
 */
#include "a15vpeLink_priv.h"


#define IS_ERR(x) (((long)(x) >= -4096) && ((long)(x) <= 0))
#define A15_VPE_BUFFER_ALIGNMENT	(16U)
#define DRM_IOCTL_OMAP_GEM_NEW_PADDR 0xC0146447


 int                   devBufFD;
Int32 A15VpeLink_drvSearchMapTbl(A15vpelink_map_tbl *mapTbl,Int32 *buf_dmafd,Int32 *uv_buf_dmafd,Int32 *v4l2_index,System_Buffer *pBuffer)
{
	UInt32 i;
	System_VideoFrameBuffer *pVideoFrame=NULL;
	
	if(pBuffer->bufType != SYSTEM_BUFFER_TYPE_VIDEO_FRAME ||!mapTbl ||mapTbl->itemNum>A15_VPE_LINK_MAX_MAP_TBL_ITEM_PER_CH)
		return -1; //errror return
	pVideoFrame = pBuffer->payload;
	OSA_assert(pVideoFrame != NULL);
	for(i=0;i<mapTbl->itemNum;i++)
	{
		if(mapTbl->item[i].buf == pVideoFrame->bufAddr[0])
		{
			if(buf_dmafd)
				*buf_dmafd = mapTbl->item[i].dma_buf_fd;
			if(uv_buf_dmafd)
				*uv_buf_dmafd = mapTbl->item[i].dma_buf_fd_uv;
			mapTbl->item[i].header = pBuffer;//record system buffer again, since it is allocated dynamically by previous link
			if(v4l2_index)
				*v4l2_index = mapTbl->item[i].v4l2_index;
			return 1; //found the item
		}
	}

	return 0;// not found, need allocate and add a new item

}

Int32 A15VpeLink_drvAddMapItem(A15vpelink_map_tbl *mapTbl,Int32 handle_buf_dmafd,Int32 handle_uv_buf_dmafd,Int32 buf_dmafd,Int32 uv_buf_dmafd,Int32 *v4l2_index,System_Buffer *pBuffer)
{
	System_VideoFrameBuffer *pVideoFrame=NULL;
	
	if(pBuffer->bufType != SYSTEM_BUFFER_TYPE_VIDEO_FRAME ||!mapTbl ||mapTbl->itemNum>=A15_VPE_LINK_MAX_MAP_TBL_ITEM_PER_CH)
		return -1; //errror return
	pVideoFrame = pBuffer->payload;
	OSA_assert(pVideoFrame != NULL);
	mapTbl->item[mapTbl->itemNum].header  = pBuffer;
	mapTbl->item[mapTbl->itemNum].buf = pVideoFrame->bufAddr[0];
	mapTbl->item[mapTbl->itemNum].handle_dma_buf_fd = handle_buf_dmafd;
	mapTbl->item[mapTbl->itemNum].handle_dma_buf_fd_uv = handle_uv_buf_dmafd;
	mapTbl->item[mapTbl->itemNum].dma_buf_fd = buf_dmafd;
	mapTbl->item[mapTbl->itemNum].dma_buf_fd_uv = uv_buf_dmafd;
	mapTbl->item[mapTbl->itemNum].v4l2_index = mapTbl->itemNum;
	if(v4l2_index)
		*v4l2_index = mapTbl->itemNum;
	//printf("A15VpeLink_DrvAddMapItem add SUCC item[%d]:%d:%d:%p \n",mapTbl->itemNum,buf_dmafd,uv_buf_dmafd,pBuffer);
	mapTbl->itemNum ++;
	return SYSTEM_LINK_STATUS_SOK;
}

Int32 A15VpeLink_drvGetSysBufFromMapTbl(A15vpelink_map_tbl *mapTbl,UInt32 v4l2_index,System_Buffer **pBuffer)
{
	UInt32 i;

	if(!mapTbl ||mapTbl->itemNum>A15_VPE_LINK_MAX_MAP_TBL_ITEM_PER_CH)
		return SYSTEM_LINK_STATUS_EFAIL; //errror return
	for(i=0;i<mapTbl->itemNum;i++)
	{
		if(mapTbl->item[i].v4l2_index == v4l2_index)
		{
			*pBuffer = mapTbl->item[i].header;
			return SYSTEM_LINK_STATUS_SOK; //found the item
		}
	}

	return SYSTEM_LINK_STATUS_EFAIL;// not found, need allocate and add a new item

}


/**
 *****************************************************************************
 * @brief:  fills 4cc, size, coplanar, colorspace based on command line input 
 *
 * @param:  format  char pointer
 * @param:  image  struct image_params pointer
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvDescribeFormat (System_VideoDataFormat format,image_params *image)
{
        image->size   = 0;
	 image->size_uv   = 0;
        image->fourcc = -1;
	 switch(format)
	 {
	 	case SYSTEM_DF_RGB24_888:
			  image->fourcc = V4L2_PIX_FMT_RGB24;
                	  image->size = image->height * image->width * 3;
                	  image->coplanar = 0;
                	  image->colorspace = V4L2_COLORSPACE_SRGB;
			break;
		case SYSTEM_DF_BGR24_888:
			  image->fourcc = V4L2_PIX_FMT_BGR24;
                	  image->size = image->height * image->width * 3;
                	  image->coplanar = 0;
                	  image->colorspace = V4L2_COLORSPACE_SRGB;
			break;

		case SYSTEM_DF_ARGB32_8888:
			  image->fourcc = V4L2_PIX_FMT_RGB32;
   	                image->size = image->height * image->width * 4;
   	                image->coplanar = 0;
   	                image->colorspace = V4L2_COLORSPACE_SRGB;
				break;
		case SYSTEM_DF_ABGR32_8888:
			  image->fourcc = V4L2_PIX_FMT_BGR32;
	                image->size = image->height * image->width * 4;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SRGB;
			break;
		case SYSTEM_DF_YUV444I:
			  image->fourcc = V4L2_PIX_FMT_YUV444;
	                image->size = image->height * image->width * 3;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422I_YVYU:
			  image->fourcc = V4L2_PIX_FMT_YVYU;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422I_YUYV:
			  image->fourcc = V4L2_PIX_FMT_YUYV;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422I_UYVY:
			  image->fourcc = V4L2_PIX_FMT_UYVY;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422I_VYUY:
			  image->fourcc = V4L2_PIX_FMT_VYUY;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422SP_UV:
			  image->fourcc = V4L2_PIX_FMT_NV16;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV422SP_VU:
		         image->fourcc = V4L2_PIX_FMT_NV61;
	                image->size = image->height * image->width * 2;
	                image->coplanar = 0;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV420SP_UV:
			  image->fourcc = V4L2_PIX_FMT_NV12;
	                //image->size = image->height * image->width * 1.5;
	                image->coplanar = 1;
			  image->size = image->height * image->width * 1;
			  image->size_uv = image->height * image->width * 0.5;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
			break;
		case SYSTEM_DF_YUV420SP_VU:
	                image->fourcc = V4L2_PIX_FMT_NV21;
	                //image->size = image->height * image->width * 1.5;
	                image->coplanar = 1;
			  image->size = image->height * image->width * 1;
			  image->size_uv = image->height * image->width * 0.5;
	                image->colorspace = V4L2_COLORSPACE_SMPTE170M;
				break;
		default:
			return 0;
			break;
	 }
       

        return 1;
}

static Int32 A15VpeLink_drvVideoFrameGetSize(System_LinkChInfo *pChInfo,UInt32 * size_Y,UInt32 * size_UV) //refer to Utils_memFrameGetSize
{
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    System_VideoDataFormat format;
    image_params image;

    memset(&image,0,sizeof(image_params));
    pChInfo->height = OSA_align(pChInfo->height, 2);
    image.width = pChInfo->width;
    image.height = pChInfo->height;	
    format = SYSTEM_LINK_CH_INFO_GET_FLAG_DATA_FORMAT(pChInfo->flags);
    //printf("A15VpeLink_DrvVideoFrameGetSize width %d height %d format %d\n",image.width,image.height,format);	
    if(A15VpeLink_drvDescribeFormat(format,&image))
    {
		*size_Y = image.size;
		*size_UV = image.size_uv;
    }

    /*
     * align size to minimum required frame buffer alignment
     */
    *size_Y = OSA_align(*size_Y, A15_VPE_BUFFER_ALIGNMENT);
    *size_UV = OSA_align(*size_UV, A15_VPE_BUFFER_ALIGNMENT);	

    return status;
}


static Int32 A15VpeLink_drvExportDmaBuf(void * vAddr, uint32_t size, uint32_t *fdBuf)
{
    int retVal = -1;
    struct dmabuf_vmem_export exp;
    exp.vaddr = (unsigned long)vAddr;
    exp.size = size;

    if(devBufFD > 0)
    {
        /* Export as DMAbuf handle */
        retVal = ioctl(devBufFD, DBUFIOC_EXPORT_VIRTMEM, &exp);
        if(retVal == 0)
        {
            *fdBuf = exp.fd;
        }
        else
        {
            printf(" exportDmaBuf failed \n ");
        }
    }

    return retVal;
}


Int32 A15VpeLink_drvConstructDmabuf(Int32 drm_fd,Int32 *handle_buf_dmafd,Int32 *handle_uv_buf_dmafd,Int32 *buf_dmafd,Int32 *uv_buf_dmafd,System_Buffer *pBuffer)
{
	Int32 handle = -ENOSYS;
	System_VideoFrameBuffer	*pVideoBuf=NULL;
	struct drm_prime_handle req;
	UInt32 size_Y=0,size_UV=0;
	Int8 ret;

	pVideoBuf = (System_VideoFrameBuffer *)pBuffer->payload;
	A15VpeLink_drvVideoFrameGetSize(&pVideoBuf->chInfo,&size_Y,&size_UV);
	Task_sleep(1000);
	//printf("A15VpeLink_DrvConstructDmabuf size caculated are Y %d UV %d\n",size_Y,size_UV);
	//printf("A15VpeLink_DrvConstructDmabuf drm_fd %d \n",drm_fd);
	
        //printf("A15VpeLink_DrvConstructDmabuf drmIoctl return SUCC  Y fd %d\n",req.fd);
	ret = A15VpeLink_drvExportDmaBuf(((UInt32)pVideoBuf->bufAddr[0], size_Y,&buf_dmafd);
	if (ret) {
		return ret;//failed
	}
        	

	if(uv_buf_dmafd && size_UV)
	{
		ret = A15VpeLink_drvExportDmaBuf(((UInt32)pVideoBuf->bufAddr[1], size_UV,& uv_buf_dmafd);
		if (ret) {
			return ret;//failed
		}
	}


	return SYSTEM_LINK_STATUS_SOK;
}

Int32 A15VpeLink_drvQueueFramesToChQue(A15VpeLink_Obj * pObj)
{
    UInt32 bufId, freeBufNum=0;
    System_LinkInQueParams *pInQueParams;
    System_BufferList bufList,bufListToPre;
    A15VpeLink_ChObj *pChObj;
    Int32 status=SYSTEM_LINK_STATUS_SOK, returnVal;
    System_Buffer *pBuffer=NULL,*pSysBuf=NULL;
    vpe_params *vpe;
    Int32 v4l2_index=-1;
    System_VideoFrameBuffer *pVideoFrame=NULL;
    System_LinkChInfo		*pChnInfo=NULL;
    Int32 handle_dmabuf=-1,handle_dmabuf_uv=-1;
    Int32 dma_fd1=-1,dma_fd2=-1;
    UInt64 timestamp=0,timestamp_local=0,timestamp_temp=0;//timestamp_end=0;
	
    pInQueParams = &pObj->createArgs.inQueParams;

    System_getLinksFullBuffers(pInQueParams->prevLinkId,
                               pInQueParams->prevLinkQueId, &bufList);
	
    if (bufList.numBuf >NUMBUF)
		return SYSTEM_LINK_STATUS_ENO_MORE_BUFFERS;
    if (bufList.numBuf)
    {
        freeBufNum = 0;

        for (bufId = 0; bufId < bufList.numBuf; bufId++)
        {
            pBuffer = bufList.buffers[bufId];

            if (pBuffer->chNum >= pObj->inQueInfo.numCh)
            {
                bufList.buffers[freeBufNum] = pBuffer;
                freeBufNum++;
                pObj->linkStats.inBufErrorCount++;
                continue;
            }
            pChObj = &pObj->chObj[pBuffer->chNum];
            vpe = &pChObj->vpePrm;

            pObj->linkStats.chStats[pBuffer->chNum].inBufRecvCount++;
	     /* in bypass mode only pick even fields */
            if(pObj->createArgs.chParams[pBuffer->chNum].deiCfg.bypass)
            {
	            //if (pChObj->nextFid == 0)
	            {
	                returnVal = A15VpeLink_drvSearchMapTbl(&pChObj->inputBufMapTbl,&dma_fd1,&dma_fd2,&v4l2_index,pBuffer);
			  if(returnVal == -1) //ERROR
			  {
			  	return SYSTEM_LINK_STATUS_EFAIL;
			  }
			  else if(returnVal == 0) //allocate new
			  	{
					pVideoFrame = (System_VideoFrameBuffer *)pBuffer->payload;
					//printf("Got Buffer from previous Link %p data %p %p type %d\n",pBuffer,pVideoFrame->bufAddr[0],pVideoFrame->bufAddr[1],pBuffer->bufType);
					pChnInfo = (System_LinkChInfo *)&pVideoFrame->chInfo;
					memcpy(pChnInfo,&pObj->inQueInfo.chInfo[0],sizeof(System_LinkChInfo));

					//printf("BUFFER channel INFO width %d height %d\n",pChnInfo->width,pChnInfo->height);
			  		status = A15VpeLink_drvConstructDmabuf(pObj->drmFd,&handle_dmabuf,&handle_dmabuf_uv,&dma_fd1,&dma_fd2,pBuffer);
					OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					status = A15VpeLink_drvAddMapItem(&pChObj->inputBufMapTbl,handle_dmabuf,handle_dmabuf_uv,dma_fd1,dma_fd2,&v4l2_index,pBuffer);
					OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					vpe->input_buf_dmafd[v4l2_index] = dma_fd1;
					vpe->input_buf_dmafd_uv[v4l2_index] = dma_fd2;
			  	}	

				A15VpeLink_drvInputQbuf(vpe,v4l2_index,pBuffer->srcTimestamp);
				pVideoFrame = (System_VideoFrameBuffer *)pBuffer->payload;
			       //printf("LINK %d: input QBUF %d %p data %p %p\n",pObj->linkId,v4l2_index,pBuffer,pVideoFrame->bufAddr[0],pVideoFrame->bufAddr[1]);
				timestamp_temp = pBuffer->srcTimestamp;
				if (!pChObj->streaming) {
					A15VpeLink_drvStreamOn(vpe->fd, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
				   	pChObj->streaming = 1;
					//printf("LINK %d: stream on FD %d \n",pObj->linkId,vpe->fd);
				   }
				   
				v4l2_index = A15VpeLink_drvOutputDqbuf(vpe,&timestamp);  // scaled image
				timestamp_local = OSA_getCurGlobalTimeInUsec();
				status = A15VpeLink_drvGetSysBufFromMapTbl(&pChObj->outputBufMapTbl,v4l2_index,&pSysBuf);
				OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
				pVideoFrame = (System_VideoFrameBuffer *)pSysBuf->payload;
				//printf("LINK %d: output DQBUF %d %p data %p %p\n",pObj->linkId,v4l2_index,pSysBuf,pVideoFrame->bufAddr[0],pVideoFrame->bufAddr[1]);
				pSysBuf->srcTimestamp = timestamp;
				pSysBuf->linkLocalTimestamp = timestamp_local;
				//printf("A15VpeLink_drvOutputDqbuf return %d %p ORG_TS %llu NOW %llu\n",v4l2_index,pSysBuf,timestamp,timestamp_local);

			       status = OSA_bufPutFullBuffer(&pObj->outObj[0].bufOutQue,pSysBuf);
	            		OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
				System_sendLinkCmd(pObj->createArgs.outQueParams[0].nextLink,SYSTEM_CMD_NEW_DATA, NULL);
				
				v4l2_index = A15VpeLink_drvInputDqbuf(vpe);
				status = A15VpeLink_drvGetSysBufFromMapTbl(&pChObj->inputBufMapTbl,v4l2_index,&pSysBuf);
				OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
				pVideoFrame = (System_VideoFrameBuffer *)pSysBuf->payload;
				//printf("LINK %d: input DQBUF %d %p data %p %p\n",pObj->linkId,v4l2_index,pSysBuf,pVideoFrame->bufAddr[0],pVideoFrame->bufAddr[1]);
				//pSysBuf = (System_Buffer *)OSA_memPhys2Virt((UInt32)pSysBuf, OSA_MEM_REGION_TYPE_SR1);
				bufListToPre.numBuf = 0x01u;
				bufListToPre.buffers[0] = pSysBuf;
            			pObj->returnedInFrames++;

            			System_putLinksEmptyBuffers(pInQueParams->prevLinkId,
                                        pInQueParams->prevLinkQueId,
                                        &bufListToPre);
						
			  vpe->input_buf_quantity++; //need to be reset when processing end

	            }
		#if 0
	            else
	            {
	                pObj->linkStats.chStats[pBuffer->chNum].inBufDropCount++;

	                // frame is not of expected FID, so release frame
	                bufList.buffers[freeBufNum] = pBuffer;
	                freeBufNum++;
	            }
		  // toggle to next required FID
                pChObj->nextFid ^= 1;
		  #endif
            	}
		else
		{
	                returnVal = A15VpeLink_drvSearchMapTbl(&pChObj->inputBufMapTbl,&dma_fd1,&dma_fd2,&v4l2_index,pBuffer);
			  if(returnVal == -1) //ERROR
			  {
			  	return SYSTEM_LINK_STATUS_EFAIL;
			  }
			  else if(returnVal == 0) //allocate new
			  	{
			  		//printf("Got Buffer from previous Link %p type %d\n",pBuffer->payload,pBuffer->bufType);
					pVideoFrame = (System_VideoFrameBuffer *)pBuffer->payload;
					pChnInfo = (System_LinkChInfo *)&pVideoFrame->chInfo;
					memcpy(pChnInfo,&pObj->inQueInfo.chInfo[0],sizeof(System_LinkChInfo));

					//printf("BUFFER channel INFO width %d height %d\n",pChnInfo->width,pChnInfo->height);
			  		status = A15VpeLink_drvConstructDmabuf(pObj->drmFd,&handle_dmabuf,&handle_dmabuf_uv,&dma_fd1,&dma_fd2,pBuffer);
					OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					status = A15VpeLink_drvAddMapItem(&pChObj->inputBufMapTbl,handle_dmabuf,handle_dmabuf_uv,dma_fd1,dma_fd2,&v4l2_index,pBuffer);
					OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					vpe->input_buf_dmafd[v4l2_index] = dma_fd1;
					vpe->input_buf_dmafd_uv[v4l2_index] = dma_fd2;
			  	}
			  
				if(pChObj->nextFid ==0)
					vpe->field = V4L2_FIELD_TOP;
				else
					vpe->field = V4L2_FIELD_BOTTOM;
				
				A15VpeLink_drvInputQbuf(vpe,v4l2_index,pBuffer->srcTimestamp);
				timestamp_temp = pBuffer->srcTimestamp;
				if (!pChObj->streaming) {
					A15VpeLink_drvStreamOn(vpe->fd, V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE);
				   	pChObj->streaming = 1;
				   }
				   
				v4l2_index = A15VpeLink_drvOutputDqbuf(vpe,&timestamp);  // scaled image
				timestamp_local = OSA_getCurGlobalTimeInUsec();
				status = A15VpeLink_drvGetSysBufFromMapTbl(&pChObj->outputBufMapTbl,v4l2_index,&pSysBuf);
				OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
				if(pChObj->nextFid ==0)
				{
					pSysBuf->srcTimestamp = timestamp;
					pSysBuf->srcTimestamp = timestamp_temp;
					pSysBuf->linkLocalTimestamp = timestamp_local;
				       status = OSA_bufPutFullBuffer(&pObj->outObj[0].bufOutQue,pSysBuf);
		            		OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					System_sendLinkCmd(pObj->createArgs.outQueParams[0].nextLink,SYSTEM_CMD_NEW_DATA, NULL);
				}
				else
				{
	    		              pObj->linkStats.chStats[pBuffer->chNum].inBufDropCount++;
	    
	    		              // frame is not of expected FID, so release frame
					bufListToPre.numBuf = 0x01u;
					bufListToPre.buffers[0] = pSysBuf;
	            			pObj->returnedInFrames++;

	            			A15VpeLink_putEmptyBuffers(&pObj->tsk,0,&bufListToPre);
		              }
				//timestamp_end = OSA_getCurGlobalTimeInUsec();
				//printf("A15VpeLink_drvOutputDqbuf return %d %p ORG_TS %llu DQ TS %llu OUT TS %llu\n",v4l2_index,pSysBuf,timestamp,timestamp_local,timestamp_end);

				if(vpe->input_buf_quantity >= 2)// 3 frames 0,1, 2
				{
					v4l2_index = A15VpeLink_drvInputDqbuf(vpe);
					OSA_assert(v4l2_index <NUMBUF);
					status = A15VpeLink_drvGetSysBufFromMapTbl(&pChObj->inputBufMapTbl,v4l2_index,&pSysBuf);
					OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
					//pSysBuf = (System_Buffer *)OSA_memPhys2Virt((UInt32)pSysBuf, OSA_MEM_REGION_TYPE_SR1);
					bufListToPre.numBuf = 0x01u;
					bufListToPre.buffers[0] = pSysBuf;
	            			pObj->returnedInFrames++;

	            			System_putLinksEmptyBuffers(pInQueParams->prevLinkId,
	                                        pInQueParams->prevLinkQueId,
	                                        &bufListToPre);
				}
			
			  vpe->input_buf_quantity++; //need to be reset when processing end
			  pChObj->nextFid ^= 1;

		}
				
        }

        if (freeBufNum)
        {
            bufList.numBuf = freeBufNum;

            System_putLinksEmptyBuffers(pInQueParams->prevLinkId,
                                        pInQueParams->prevLinkQueId, &bufList);
        }
    }

    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *******************************************************************************
 *
 * \brief Function to set run time output frame rate
 *
 *        Set run time output frame rate, frame rate can be set for a
 *        - specific output queue
 *        - of a specific channel
 *
 * \param   pObj     [IN] VPE Link Instance handle
 * \param   VpeLink_ChFpsParams* [IN] VPE FPS parameters
 *
 * \return  status   [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvSetFrameRate(A15VpeLink_Obj * pObj, A15VpeLink_ChFpsParams * params)
{
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    A15VpeLink_ChObj *pChObj;

    if (params->chId < pObj->inQueInfo.numCh)
    {
        pChObj = &pObj->chObj[params->chId];

        /*
         * Stream 0 maps to Queue 0 - VPE_LINK_OUT_QUE_ID_0
         * Stream 1 maps to Queue 1 - VPE_LINK_OUT_QUE_ID_1
         */

        OSA_resetSkipBufContext(
            &pChObj->frameSkipCtx,
            params->inputFrameRate,
            params->outputFrameRate
            );
    }

    return (status);
}

/**
 *******************************************************************************
 *
 * \brief Function to run time enable/disable a channel
 *
 *        Set run time enable/disable a channel of a specific output queue
 *
 * \param   pObj     [IN] VPE Link Instance handle
 * \param   VpeLink_ChannelInfo* [IN] VPE channel info parameters
 *
 * \return  status   [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvSetChannelInfo(A15VpeLink_Obj * pObj,
                                A15VpeLink_ChannelInfo *channelInfo)
{
    Int32 status = SYSTEM_LINK_STATUS_SOK;
    A15VpeLink_ChObj *pChObj;

    OSA_assert(channelInfo->chId < pObj->inQueInfo.numCh);
    OSA_assert(channelInfo->outQueId  < (A15_VPE_LINK_OUT_QUE_ID_MAX));

    pChObj = &pObj->chObj[channelInfo->chId];
    pChObj->enableOut= channelInfo->enable;

    return status;
}
/**
 *****************************************************************************
 * @brief:  open the device
 *
 * @return: vpe  struct vpe pointer 
 *****************************************************************************
*/
Int32 A15VpeLink_drvOpen(A15VpeLink_ChObj *pChObj)
{
	Int8 devname[20] = "/dev/video0";
	vpe_params *vpe = &pChObj->vpePrm;

	vpe->fd =  open(devname, O_RDWR);
        if(vpe->fd < 0)
                pexit("Cant open %s\n", devname);

        printf("vpe:%s open success!!!fd %d\n", devname,vpe->fd);
	 devBufFD = open("/dev/vmemexp", O_RDWR | O_CLOEXEC);
	return vpe->fd;
}
Int32 A15VpeLink_drvDeleteVpeOutChBufferQueue (A15VpeLink_Obj * pObj, UInt32 outId)
{
    Int32 status;
    UInt32 chId;
    A15VpeLink_OutObj *pOutObj = &pObj->outObj[outId];

    for (chId=0; chId<pObj->inQueInfo.numCh; chId++)
    {
        if (pOutObj->numFrames[chId] > 0)
        {
            status = OSA_queDelete(&pOutObj->emptyBufQue[chId]);
            OSA_assert(status == SYSTEM_LINK_STATUS_SOK);
        }
    }
    close(devBufFD);
    return SYSTEM_LINK_STATUS_SOK;
}

/**
 *****************************************************************************
 * @brief:  close the device and free memory
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvClose(A15VpeLink_Obj * pObj)
{
	A15VpeLink_ChObj *pChObj = &(pObj->chObj[0]);
	vpe_params *vpe = &(pChObj->vpePrm);
	UInt32	    i;

	for(i=0;i<pChObj->inputBufMapTbl.itemNum;i++)
	{
		if(pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd)
		{
			A15VpeLink_drvCloseGemHandle(pObj->drmFd,pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd);
			//printf("A15VpeLink_drvClose input %d close gem handle %d(fd %d)\n",i,pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd,pChObj->inputBufMapTbl.item[i].dma_buf_fd);
		}
		if(pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd_uv)
		{
			A15VpeLink_drvCloseGemHandle(pObj->drmFd,pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd_uv);
			//printf("A15VpeLink_drvClose input %d close UV gem handle %d(fd %d)\n",i,pChObj->inputBufMapTbl.item[i].handle_dma_buf_fd_uv,pChObj->inputBufMapTbl.item[i].dma_buf_fd_uv);
		}
		Task_sleep(1000);
		
	}

	for(i=0;i<pChObj->outputBufMapTbl.itemNum;i++)
	{
		if(pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd)
		{
			A15VpeLink_drvCloseGemHandle(pObj->drmFd,pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd);
			//printf("A15VpeLink_drvClose output %d close gem handle %d(fd %d)\n",i,pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd,pChObj->outputBufMapTbl.item[i].dma_buf_fd);
		}
		if(pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd_uv)
		{
			A15VpeLink_drvCloseGemHandle(pObj->drmFd,pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd_uv);
			//printf("A15VpeLink_drvClose output %d close UV gem handle %d(fd %d)\n",i,pChObj->outputBufMapTbl.item[i].handle_dma_buf_fd_uv,pChObj->outputBufMapTbl.item[i].dma_buf_fd_uv);
		}
		Task_sleep(1000);
	}
	
	close(vpe->fd);
	close(pObj->drmFd);
	printf("A15VpeLink_drvClose close V4L2 fd %d DRM fd %d\n",vpe->fd,pObj->drmFd);

	return 0;
}


/**
 *****************************************************************************
 * @brief:  sets control, howmany jobs to be handled on multi instance 
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: 0 on success 
 *****************************************************************************
*/
static Int32  A15VpeLink_drvSetCtrl(A15VpeLink_ChObj *pChObj)
{
	Int32 ret;
	struct	v4l2_control ctrl;
	vpe_params *vpe = &pChObj->vpePrm;
	
	memset(&ctrl, 0, sizeof(ctrl));
	ctrl.id = V4L2_CID_TRANS_NUM_BUFS;
	ctrl.value = vpe->translen;
	ret = ioctl(vpe->fd, VIDIOC_S_CTRL, &ctrl);
	if (ret < 0)
		pexit("A15VpeLink_drvSetCtrl: S_CTRL failed! fd %d id %d value %d\n",vpe->fd,ctrl.id,ctrl.value);
	
	return 0;
}

/**
 *******************************************************************************
 *
 * \brief Function to set the scalar coefficients
 *
 *        Check the input and output resolution and set the appropriate
 *        scalar coefficients. Also Program VPE scalar with these coefficients
 *
 * \param   pObj     [IN] VPE Link Instance handle
 *
 * \return  retVal   [OUT] return SYSTEM_LINK_STATUS_SOK on success
 *
 *******************************************************************************
 */
Int32 A15VpeLink_drvSetScCoeffs(A15VpeLink_ChObj *pChObj)
{
    Int32 retVal = SYSTEM_LINK_STATUS_SOK;
    int ret = 0;

	vpe_params *vpe = &pChObj->vpePrm;
	if ((vpe->crop.c.top == 0) && (vpe->crop.c.left == 0) &&
	    (vpe->crop.c.width == 0) && (vpe->crop.c.height == 0)) {
		dprintf("setting default crop params\n");
		vpe->crop.c.top = 0;
		vpe->crop.c.left = 0;
		vpe->crop.c.width = vpe->src.width;
		vpe->crop.c.height = vpe->src.height;
		vpe->crop.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	}
       printf("A15VpeLink_drvSetScCoeffs width %d height %d \n",vpe->crop.c.width,vpe->crop.c.height);
	ret = ioctl(vpe->fd, VIDIOC_S_CROP, &vpe->crop);
	if (ret < 0)
	{
		dprintf("error setting crop\n");
		retVal = SYSTEM_LINK_STATUS_EFAIL;
	}
    return (retVal);
}

/**
 *****************************************************************************
 * @brief:  Intialize the vpe input by calling set_control, set_format,
 *	    set_crop, refbuf ioctls
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvInputInit(A15VpeLink_ChObj *pChObj)
{
	Int32 ret=SYSTEM_LINK_STATUS_SOK;
	struct v4l2_format fmt;
	struct v4l2_requestbuffers rqbufs;
	vpe_params *vpe = &pChObj->vpePrm;
	
	A15VpeLink_drvSetCtrl(pChObj);
		
	memset(&fmt, 0, sizeof fmt);
	fmt.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;

	ret = ioctl(vpe->fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0)
		pexit( "vpe i/p: G_FMT_1 failed: %s\n", strerror(errno));

	fmt.fmt.pix_mp.width = vpe->src.width;
	fmt.fmt.pix_mp.height = vpe->src.height;
	fmt.fmt.pix_mp.pixelformat = vpe->src.fourcc;

	switch (vpe->deint) {
	case 1:
		fmt.fmt.pix_mp.field = V4L2_FIELD_ALTERNATE;
		break;
	case 2:
		fmt.fmt.pix_mp.field = V4L2_FIELD_SEQ_TB;
		break;
	case 0:
	default:
		fmt.fmt.pix_mp.field = V4L2_FIELD_ANY;
		break;
	}

	ret = ioctl(vpe->fd, VIDIOC_S_FMT, &fmt);
	if (ret < 0) {
		pexit( "vpe i/p: S_FMT failed: %s %d %d %d\n", strerror(errno),vpe->src.width, vpe->src.height,vpe->src.fourcc);
	} else {
                vpe->src.size = fmt.fmt.pix_mp.plane_fmt[0].sizeimage;
                vpe->src.size_uv = fmt.fmt.pix_mp.plane_fmt[1].sizeimage;
        }

	ret = ioctl(vpe->fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0)
		pexit( "vpe i/p: G_FMT_2 failed: %s\n", strerror(errno));

	printf("vpe i/p: G_FMT: width = %u, height = %u, 4cc = %.4s\n",
			fmt.fmt.pix_mp.width, fmt.fmt.pix_mp.height,
			(char*)&fmt.fmt.pix_mp.pixelformat);

	A15VpeLink_drvSetScCoeffs(pChObj);

	memset(&rqbufs, 0, sizeof(rqbufs));
	rqbufs.count = NUMBUF;
	rqbufs.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	rqbufs.memory = V4L2_MEMORY_DMABUF;

	ret = ioctl(vpe->fd, VIDIOC_REQBUFS, &rqbufs);
	if (ret < 0)
		pexit( "vpe i/p: REQBUFS failed: %s\n", strerror(errno));

	vpe->src.numbuf = rqbufs.count;
	dprintf("vpe i/p: allocated buffers = %d\n", rqbufs.count);
	
	return ret;

}

/**
 *****************************************************************************
 * @brief:  Initialize vpe output by calling set_format, reqbuf ioctls.
 *	    Also allocates buffer to display the vpe output. 
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvOutputInit(A15VpeLink_Obj * pObj)
{
	Int32 ret;
	struct v4l2_format fmt;
	struct v4l2_requestbuffers rqbufs;
	A15VpeLink_ChObj *pChObj = &pObj->chObj[0];
	vpe_params *vpe = &pChObj->vpePrm;
	
	memset(&fmt, 0, sizeof fmt);
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;

	ret = ioctl(vpe->fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0)
		pexit( "vpe o/p: G_FMT_1 failed: %s\n", strerror(errno));

	fmt.fmt.pix_mp.width = vpe->dst.width;
	fmt.fmt.pix_mp.height = vpe->dst.height;
	fmt.fmt.pix_mp.pixelformat = vpe->dst.fourcc;
	fmt.fmt.pix_mp.field = V4L2_FIELD_ANY;

	ret = ioctl(vpe->fd, VIDIOC_S_FMT, &fmt);
	if (ret < 0)
		pexit( "vpe o/p: S_FMT failed: %s %d %d %d\n", strerror(errno),vpe->dst.width,vpe->dst.height,vpe->dst.fourcc);

	ret = ioctl(vpe->fd, VIDIOC_G_FMT, &fmt);
	if (ret < 0)
		pexit( "vpe o/p: G_FMT_2 failed: %s\n", strerror(errno));

	printf("vpe o/p: G_FMT: width = %u, height = %u, 4cc = %.4s\n",
			fmt.fmt.pix_mp.width, fmt.fmt.pix_mp.height,
			(char*)&fmt.fmt.pix_mp.pixelformat);

	memset(&rqbufs, 0, sizeof(rqbufs));
	rqbufs.count = NUMBUF;
	rqbufs.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	rqbufs.memory = V4L2_MEMORY_DMABUF;

	ret = ioctl(vpe->fd, VIDIOC_REQBUFS, &rqbufs);
	if (ret < 0)
		pexit( "vpe o/p: REQBUFS failed: %s\n", strerror(errno));
	return 0;
}

/**
 *****************************************************************************
 * @brief:  queue buffer to vpe input 
 *
 * @param:  vpe  struct vpe pointer
 * @param:  index  buffer index to queue
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvInputQbuf(vpe_params *vpe, Int32 index,UInt64 timestamp)
{
	Int32 ret;
	struct v4l2_buffer buf;
	struct v4l2_plane planes[2];

	dprintf("vpe: src QBUF (%d):%s field", vpe->field,
		vpe->field==V4L2_FIELD_TOP?"top":"bottom");

	memset(&buf, 0, sizeof buf);
	memset(planes, 0, sizeof planes);

	planes[0].length = planes[0].bytesused = vpe->src.size;
	if(vpe->src.coplanar)
		planes[1].length = planes[1].bytesused = vpe->src.size_uv;

	planes[0].data_offset = planes[1].data_offset = 0;

	buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	buf.memory = V4L2_MEMORY_DMABUF;
	buf.index = index;
	buf.m.planes = planes;
	buf.field = vpe->field;
	if(vpe->src.coplanar)
		buf.length = 2;
	else
		buf.length = 1;

	buf.m.planes[0].m.fd = vpe->input_buf_dmafd[index];
	if(vpe->src.coplanar)
		buf.m.planes[1].m.fd = vpe->input_buf_dmafd_uv[index];
	buf.timestamp.tv_usec = timestamp;
	buf.timestamp.tv_sec = 0;	
	/*printf( "A15VpeLink_drvInputQbuf: index = %d Param %d:%d:%d:%d:%d\n",
			 index,planes[0].length,planes[1].length,buf.field,buf.m.planes[0].m.fd,buf.m.planes[1].m.fd);*/
	ret = ioctl(vpe->fd, VIDIOC_QBUF, &buf);
	if (ret < 0)
		pexit( "vpe i/p: QBUF failed: %s, index = %d Param %d:%d:%d:%d:%d\n",
			strerror(errno), index,planes[0].length,planes[1].length,buf.field,buf.m.planes[0].m.fd,buf.m.planes[1].m.fd);
	
	vpe->input_buf_num++;
	return 0;
}

/**
 *****************************************************************************
 * @brief:  queue buffer to vpe output 
 *
 * @param:  vpe  struct vpe pointer
 * @param:  index  buffer index to queue
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvOutputQbuf(vpe_params *vpe, Int32 index)
{
	Int32 ret;
	struct v4l2_buffer buf;
	struct v4l2_plane planes[2];

	dprintf("vpe output buffer queue\n");

	memset(&buf, 0, sizeof buf);
	memset(planes, 0, sizeof planes);

	buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	buf.memory = V4L2_MEMORY_DMABUF;
	buf.index = index;
	buf.m.planes = planes;
	if(vpe->dst.coplanar)
		buf.length = 2;
	else
		buf.length = 1;

	buf.m.planes[0].m.fd = vpe->output_buf_dmafd[index];

	if(vpe->dst.coplanar)
		buf.m.planes[1].m.fd = vpe->output_buf_dmafd_uv[index];

	ret = ioctl(vpe->fd, VIDIOC_QBUF, &buf);
	if (ret < 0)
		pexit( "vpe o/p: QBUF failed: %s, index = %d buf.length=%d fd_Y %d fd_UV %d\n",
			strerror(errno), index, buf.length,buf.m.planes[0].m.fd,buf.m.planes[1].m.fd);
	
	vpe->output_buf_num++;
	return 0;
}

/**
 *****************************************************************************
 * @brief:  start stream 
 *
 * @param:  fd  device fd
 * @param:  type  buffer type (CAPTURE or OUTPUT)
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvStreamOn(Int32 fd, Int32 type)
{
	Int32 ret;

	ret = ioctl(fd, VIDIOC_STREAMON, &type);
	if (ret < 0)
		pexit("STREAMON failed,  %d: %s\n", type, strerror(errno));

	dprintf("stream ON: done! fd = %d,  type = %d\n", fd, type);

	return 0;
}

/**
 *****************************************************************************
 * @brief:  stop stream 
 *
 * @param:  fd  device fd
 * @param:  type  buffer type (CAPTURE or OUTPUT)
 *
 * @return: 0 on success 
 *****************************************************************************
*/
Int32  A15VpeLink_drvStreamOff(Int32 fd, Int32 type)
{
	Int32 ret;

	ret = ioctl(fd, VIDIOC_STREAMOFF, &type);
	if (ret < 0)
		pexit("STREAMOFF failed, %d: %s\n", type, strerror(errno));

	dprintf("stream OFF: done! fd = %d,  type = %d\n", fd, type);

	return 0;
}

/**
 *****************************************************************************
 * @brief:  dequeue vpe input buffer  
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: buf.index index of dequeued buffer
 *****************************************************************************
*/
Int32  A15VpeLink_drvInputDqbuf(vpe_params *vpe)
{
	Int32 ret;
	struct v4l2_buffer buf;
	struct v4l2_plane planes[2];
	
	dprintf("vpe input dequeue buffer\n");
	
	memset(&buf, 0, sizeof buf);
	memset(planes, 0, sizeof planes);

	buf.type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
	buf.memory = V4L2_MEMORY_DMABUF;
        buf.m.planes = planes;
	if(vpe->src.coplanar)
		buf.length = 2;
	else
		buf.length = 1;
	ret = ioctl(vpe->fd, VIDIOC_DQBUF, &buf);
	if (ret < 0)
		pexit("vpe i/p: DQBUF failed: %s\n", strerror(errno));

	dprintf("vpe i/p: DQBUF index = %d\n", buf.index);

	vpe->input_buf_num--;
	return buf.index;
}

/**
 *****************************************************************************
 * @brief:  dequeue vpe output buffer
 *
 * @param:  vpe  struct vpe pointer
 *
 * @return: buf.index index of dequeued buffer
 *****************************************************************************
*/
Int32  A15VpeLink_drvOutputDqbuf(vpe_params *vpe,UInt64 *timestamp)
{
	Int32 ret;
	struct v4l2_buffer buf;
	struct v4l2_plane planes[2];

	dprintf("vpe output dequeue buffer\n");

	memset(&buf, 0, sizeof buf);
	memset(planes, 0, sizeof planes);

	buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	buf.memory = V4L2_MEMORY_DMABUF;
        buf.m.planes = planes;
	if(vpe->dst.coplanar)
		buf.length = 2;
	else
		buf.length = 1;
	ret = ioctl(vpe->fd, VIDIOC_DQBUF, &buf);
	if (ret < 0)
		pexit("vpe o/p: DQBUF failed: %s\n", strerror(errno));
       if(timestamp)
	   	*timestamp = buf.timestamp.tv_usec;
	dprintf("vpe o/p: DQBUF index = %d\n", buf.index);

	vpe->output_buf_num--;
	return buf.index;
}

/* Nothing beyond this point */

